/* Projet Propre en ordre 2023
 * graphic_gui.h
 * Leo Sierra 341942
 * Alexandros Dellios 355873
*/
#ifndef GTKMM_GRAPHIC_GUI_H
#define GTKMM_GRAPHIC_GUI_H

#include <gtkmm/drawingarea.h>
#include "graphic.h"

void graphic_set_context(const Cairo::RefPtr<Cairo::Context>& cr);

#endif

